package com.vocabshock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque

/**
 * 监听「不背单词」中的按钮点击：不认识 / 模糊 / 忘记 -> 触发设备输出。
 */
class VocabWatchService : AccessibilityService() {

    private var lastTriggerAt = 0L
    private val history = ArrayDeque<Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        Config.load(this)
        DgLabBridge.ensureStarted(this)
        DgLabBridge.logSink?.invoke("无障碍服务已连接")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!Config.enabled) return

        val pkg = event.packageName?.toString() ?: return
        val target = Config.targetPackage.trim()
        if (target.isNotEmpty() && pkg != target) return

        // 只在真正点击时触发，避免按钮常驻导致误判
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return

        val text = collectText(event.source) + " " + (event.text?.joinToString(" ") ?: "")

        if (Config.debug) {
            android.util.Log.d("VocabShock", "click pkg=$pkg text=$text")
            DgLabBridge.logSink?.invoke("点击：$pkg | ${text.trim()}")
        }

        val level = Config.levelOf(text) ?: return

        val now = System.currentTimeMillis()

        // 冷却
        if (now - lastTriggerAt < Config.cooldownMs) return

        // 每分钟次数限制
        while (history.isNotEmpty() && now - history.first() > 60_000) history.removeFirst()
        if (history.size >= Config.maxPerMinute) {
            android.util.Log.d("VocabShock", "触发过于频繁，已跳过")
            DgLabBridge.logSink?.invoke("⚠️ 触发过于频繁（每分钟上限 ${Config.maxPerMinute} 次），已跳过")
            return
        }

        lastTriggerAt = now
        history.addLast(now)
        DgLabBridge.punish(level)
    }

    override fun onInterrupt() {}

    private fun collectText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        walk(node, sb, 0)
        return sb.toString()
    }

    private fun walk(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 2) return
        node.text?.let { sb.append(it).append(' ') }
        node.contentDescription?.let { sb.append(it).append(' ') }
        val count = node.childCount
        for (i in 0 until minOf(count, 8)) {
            val child = node.getChild(i) ?: continue
            walk(child, sb, depth + 1)
        }
    }
}
