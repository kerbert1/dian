package com.vocabshock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 通知栏「紧急停止」按钮 */
class StopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Config.load(context)
        DgLabBridge.ensureStarted(context)
        DgLabBridge.emergencyStop()
        Config.save(context)
        Notifications.cancel(context)
    }
}
