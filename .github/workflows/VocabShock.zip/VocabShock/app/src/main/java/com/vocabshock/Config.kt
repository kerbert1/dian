package com.vocabshock

import android.content.Context
import kotlin.math.max
import kotlin.math.min

/**
 * 全局配置。所有参数在主界面可调，保存在 SharedPreferences。
 */
object Config {

    // ---------- 开关 ----------
    /** 总开关：关闭后不再触发任何输出 */
    var enabled: Boolean = true
    /** 调试模式：把所有点击事件打印到日志，用于确认按钮文字能否被捕获 */
    var debug: Boolean = false

    // ---------- 监听目标 ----------
    /** 目标 App 包名，留空表示监听所有 App（建议填写「不背单词」的包名） */
    var targetPackage: String = ""
    /** 关键词：不认识（最强） */
    var wordsHard: String = "不认识"
    /** 关键词：忘记 / 忘记了（次强） */
    var wordsMid: String = "忘记,忘记了"
    /** 关键词：模糊（最轻） */
    var wordsLight: String = "模糊"

    // ---------- 三档惩罚参数（强度 0-200，时长 毫秒） ----------
    var strengthHard: Int = 35
    var durationHard: Long = 1500
    var strengthMid: Int = 25
    var durationMid: Long = 1200
    var strengthLight: Int = 12
    var durationLight: Long = 600

    // ---------- 设备 ----------
    /** 输出通道：1 = A 通道，2 = B 通道 */
    var channel: Int = 1
    /** 通道编号基准：1 表示 A=1/B=2；0 表示 A=0/B=1（不同版本协议有差异，无效时切换试试） */
    var channelBase: Int = 1
    /** 实验性：下发自定义波形脉冲，而不是直接设置强度 */
    var useWaveform: Boolean = false

    // ---------- 安全限制 ----------
    /** 强度硬上限，任何情况都不会超过 */
    var hardMaxStrength: Int = 60
    /** 单次输出时长上限（毫秒） */
    var maxDuration: Long = 3000
    /** 两次触发之间的最小间隔（毫秒） */
    var cooldownMs: Long = 3000
    /** 每 60 秒最多触发次数，超出后本分钟不再输出 */
    var maxPerMinute: Int = 8

    // ---------- 网络 ----------
    /** 本机 WebSocket 服务端端口 */
    var port: Int = 9999
    /** 局域网 IP 覆盖，留空则自动获取 */
    var ipOverride: String = ""

    /** 控制端 ID（首次生成后固定保存，二维码里包含它） */
    var clientId: String = ""

    fun clampStrength(v: Int): Int = min(max(v, 0), min(hardMaxStrength, 200))
    fun clampDuration(v: Long): Long = min(max(v, 100L), maxDuration)

    private const val PREF = "vocabshock"

    fun load(c: Context) {
        val sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        enabled = sp.getBoolean("enabled", enabled)
        debug = sp.getBoolean("debug", debug)
        targetPackage = sp.getString("targetPackage", targetPackage) ?: ""
        wordsHard = sp.getString("wordsHard", wordsHard) ?: wordsHard
        wordsMid = sp.getString("wordsMid", wordsMid) ?: wordsMid
        wordsLight = sp.getString("wordsLight", wordsLight) ?: wordsLight
        strengthHard = sp.getInt("strengthHard", strengthHard)
        durationHard = sp.getLong("durationHard", durationHard)
        strengthMid = sp.getInt("strengthMid", strengthMid)
        durationMid = sp.getLong("durationMid", durationMid)
        strengthLight = sp.getInt("strengthLight", strengthLight)
        durationLight = sp.getLong("durationLight", durationLight)
        channel = sp.getInt("channel", channel)
        channelBase = sp.getInt("channelBase", channelBase)
        useWaveform = sp.getBoolean("useWaveform", useWaveform)
        hardMaxStrength = sp.getInt("hardMaxStrength", hardMaxStrength)
        maxDuration = sp.getLong("maxDuration", maxDuration)
        cooldownMs = sp.getLong("cooldownMs", cooldownMs)
        maxPerMinute = sp.getInt("maxPerMinute", maxPerMinute)
        port = sp.getInt("port", port)
        ipOverride = sp.getString("ipOverride", ipOverride) ?: ""
        clientId = sp.getString("clientId", "") ?: ""
        if (clientId.isBlank()) {
            clientId = java.util.UUID.randomUUID().toString()
            sp.edit().putString("clientId", clientId).apply()
        }
    }

    fun save(c: Context) {
        val sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        sp.edit()
            .putBoolean("enabled", enabled)
            .putBoolean("debug", debug)
            .putString("targetPackage", targetPackage)
            .putString("wordsHard", wordsHard)
            .putString("wordsMid", wordsMid)
            .putString("wordsLight", wordsLight)
            .putInt("strengthHard", strengthHard)
            .putLong("durationHard", durationHard)
            .putInt("strengthMid", strengthMid)
            .putLong("durationMid", durationMid)
            .putInt("strengthLight", strengthLight)
            .putLong("durationLight", durationLight)
            .putInt("channel", channel)
            .putInt("channelBase", channelBase)
            .putBoolean("useWaveform", useWaveform)
            .putInt("hardMaxStrength", hardMaxStrength)
            .putLong("maxDuration", maxDuration)
            .putLong("cooldownMs", cooldownMs)
            .putInt("maxPerMinute", maxPerMinute)
            .putInt("port", port)
            .putString("ipOverride", ipOverride)
            .putString("clientId", clientId)
            .apply()
    }

    /** 判断点击文本属于哪一档：3=不认识，2=忘记，1=模糊，null=不触发 */
    fun levelOf(text: String): Int? {
        if (text.isBlank()) return null
        if (hit(text, wordsHard)) return 3
        if (hit(text, wordsMid)) return 2
        if (hit(text, wordsLight)) return 1
        return null
    }

    private fun hit(text: String, keywords: String): Boolean {
        return keywords.split(",", "，", "|").any { kw ->
            kw.isNotBlank() && text.contains(kw.trim())
        }
    }
}
