package com.vocabshock

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.java_websocket.WebSocket
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.handshake.ServerHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.InterfaceAddress
import java.net.NetworkInterface
import java.net.URI
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * DG-LAB SOCKET 协议桥接层。
 *
 * DG-LAB App 是 WebSocket「客户端」，它主动连接第三方服务端。因此本 App 内部同时扮演：
 *   1) WebSocket 服务端（监听 0.0.0.0:port，等待 DG-LAB App 扫码连入）
 *   2) 控制端客户端（连接自己的服务端，获得 clientId，向 App 下发指令）
 *
 * 协议要点（V2 / 兼容 3.0 的旧控制协议）：
 *   连接建立 -> 服务端下发 {"type":"bind","clientId":<该连接ID>,"targetId":"","message":"targetId"}
 *   App 请求 -> {"type":"bind","clientId":<控制端ID>,"targetId":<App ID>,"message":"DGLAB"}
 *   绑定完成 -> {"type":"bind","clientId":...,"targetId":...,"message":"200"}
 *   设置强度 -> {"type":"msg",...,"message":"strength-<通道>+<0降/1增/2设>+<值>"}
 */
object DgLabBridge {

    private const val TAG = "VocabShock"
    private const val HEARTBEAT_MS = 30_000L

    /** 日志回调（主界面用） */
    var logSink: ((String) -> Unit)? = null

    /** App 是否已绑定 */
    @Volatile
    var bound: Boolean = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var server: DgServer? = null
    private var ctrl: CtrlClient? = null

    private var appId: String? = null
    private var stopRunnable: Runnable? = null

    private fun log(msg: String) {
        Log.d(TAG, msg)
        mainHandler.post { logSink?.invoke(msg) }
    }

    // ------------------------------------------------------------------
    // 启动 / 停止
    // ------------------------------------------------------------------

    fun ensureStarted(context: Context) {
        Config.load(context)
        if (server == null) {
            try {
                val s = DgServer(Config.port)
                s.isReuseAddr = true
                s.start()
                server = s
                log("服务端已启动，端口 ${Config.port}")
            } catch (e: Exception) {
                log("服务端启动失败：${e.message}")
                return
            }
        }
        if (ctrl == null || ctrl?.isOpen == false) {
            val c = CtrlClient(URI("ws://127.0.0.1:${Config.port}/"))
            c.connect()
            ctrl = c
        }
        scheduleHeartbeat()
    }

    fun restart(context: Context) {
        stopInternal()
        ensureStarted(context)
    }

    private fun stopInternal() {
        try {
            server?.stop(500)
        } catch (e: Exception) {
            Log.w(TAG, "stop server: ${e.message}")
        }
        server = null
        try {
            ctrl?.closeBlocking()
        } catch (e: Exception) {
            Log.w(TAG, "close ctrl: ${e.message}")
        }
        ctrl = null
        appId = null
        bound = false
        mainHandler.removeCallbacks(heartbeatTask)
    }

    private val heartbeatTask = object : Runnable {
        override fun run() {
            server?.sendHeartbeats()
            mainHandler.postDelayed(this, HEARTBEAT_MS)
        }
    }

    private fun scheduleHeartbeat() {
        mainHandler.removeCallbacks(heartbeatTask)
        mainHandler.postDelayed(heartbeatTask, HEARTBEAT_MS)
    }

    /** 配对二维码内容 */
    fun qrContent(context: Context): String {
        val ip = Config.ipOverride.ifBlank { lanIp() }
        return "https://www.dungeon-lab.com/app-download.php#DGLAB-SOCKET#ws://$ip:${Config.port}/${Config.clientId}"
    }

    fun lanIp(): String {
        return try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf = en.nextElement()
                if (!intf.isUp) continue
                val addrs: List<InterfaceAddress> = intf.interfaceAddresses
                for (ia in addrs) {
                    val a = ia.address
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) {
                        return a.hostAddress ?: continue
                    }
                }
            }
            "127.0.0.1"
        } catch (e: Exception) {
            "127.0.0.1"
        }
    }

    // ------------------------------------------------------------------
    // 指令
    // ------------------------------------------------------------------

    private fun channelNumber(): Int = if (Config.channelBase == 1) Config.channel else Config.channel - 1
    private fun channelLetter(): String = if (Config.channel == 1) "A" else "B"

    /** 触发一次输出：设定强度 -> 持续 durationMs -> 归零 */
    fun punish(level: Int) {
        if (!Config.enabled) {
            log("总开关关闭，忽略触发")
            return
        }
        if (!bound || appId == null) {
            log("未与 DG-LAB App 绑定，忽略触发")
            return
        }
        val (strength, duration) = when (level) {
            3 -> Config.strengthHard to Config.durationHard
            2 -> Config.strengthMid to Config.durationMid
            else -> Config.strengthLight to Config.durationLight
        }
        val s = Config.clampStrength(strength)
        val d = Config.clampDuration(duration)

        cancelPendingStop()
        if (Config.useWaveform) {
            sendPulse(s, d)
        } else {
            sendMsg("strength-${channelNumber()}+2+$s")
        }
        log("触发输出：档位$level 强度=$s 时长=${d}ms")

        val r = Runnable {
            sendMsg("strength-${channelNumber()}+2+0")
            log("输出结束，已归零")
        }
        stopRunnable = r
        mainHandler.postDelayed(r, d)
    }

    /** 测试输出（忽略总开关以外的限制，仍受强度上限保护） */
    fun testPulse() {
        if (!bound || appId == null) {
            log("未绑定，无法测试")
            return
        }
        val s = Config.clampStrength(Config.strengthLight)
        cancelPendingStop()
        sendMsg("strength-${channelNumber()}+2+$s")
        val r = Runnable { sendMsg("strength-${channelNumber()}+2+0") }
        stopRunnable = r
        mainHandler.postDelayed(r, 800)
        log("测试输出：强度=$s 时长=800ms")
    }

    /** 紧急停止：立刻归零并清空波形队列 */
    fun emergencyStop() {
        cancelPendingStop()
        sendMsg("strength-${channelNumber()}+2+0")
        sendMsg("strength-${if (channelNumber() == 1) 2 else 1}+2+0")
        sendMsg("clear-${channelNumber()}")
        Config.enabled = false
        log("已紧急停止：双通道归零，总开关关闭")
    }

    private fun cancelPendingStop() {
        stopRunnable?.let { mainHandler.removeCallbacks(it) }
        stopRunnable = null
    }

    private fun sendPulse(strength: Int, durationMs: Long) {
        val units = (durationMs / 100).coerceIn(1, 100)
        val arr = (0 until units.toInt()).joinToString(",") { i ->
            val ratio = (i + 1).toFloat() / units.toFloat()
            val v = (strength * (0.35f + 0.65f * ratio)).toInt().coerceIn(0, 100)
            val hex = "%02X".format(v)
            "\"0A0A0A0A$hex$hex$hex$hex\""
        }
        sendMsg("pulse-${channelLetter()}:[$arr]")
    }

    private fun sendMsg(message: String) {
        val target = appId ?: return
        val json = JSONObject().apply {
            put("type", "msg")
            put("clientId", Config.clientId)
            put("targetId", target)
            put("message", message)
        }
        ctrl?.send(json.toString())
    }

    // ------------------------------------------------------------------
    // WebSocket 服务端
    // ------------------------------------------------------------------

    private inner class DgServer(port: Int) : WebSocketServer(InetSocketAddress(port)) {

        private val connIds = ConcurrentHashMap<WebSocket, String>()

        override fun onStart() {
            log("WebSocket 服务端 onStart")
        }

        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            val path = (handshake.resourceDescriptor ?: "").substringBefore('?').trim('/')
            if (path.isNotEmpty() && path == Config.clientId) {
                // DG-LAB App 通过二维码里的地址连入
                val id = UUID.randomUUID().toString()
                connIds[conn] = id
                appId = id
                sendTo(conn, id, "", "targetId", type = "bind")
                log("DG-LAB App 已连接，等待绑定…")
            } else {
                // 控制端（本 App 内部）
                connIds[conn] = Config.clientId
                sendTo(conn, Config.clientId, "", "targetId", type = "bind")
            }
        }

        override fun onMessage(conn: WebSocket, message: String) {
            try {
                val o = JSONObject(message)
                val type = o.optString("type")
                val cid = o.optString("clientId")
                val tid = o.optString("targetId")
                val body = o.optString("message")

                when {
                    type == "bind" && body == "DGLAB" -> {
                        if (cid == Config.clientId && tid.isNotEmpty()) {
                            appId = tid
                            bound = true
                            // 通知双方绑定成功
                            connIds.forEach { (c, id) ->
                                if (id == tid) sendTo(c, cid, tid, "200", type = "bind")
                            }
                            ctrl?.let { c ->
                                if (connIds[c] == Config.clientId) sendTo(c, cid, tid, "200", type = "bind")
                            }
                            log("✅ 绑定成功，App ID=${tid.take(8)}…")
                        }
                    }

                    type == "msg" && body.startsWith("strength-") -> {
                        // App 上报当前强度，转发给控制端用于显示
                        ctrl?.takeIf { it.isOpen }?.send(message)
                    }

                    type == "break" -> {
                        bound = false
                        appId = null
                        log("连接断开（break）")
                    }

                    type == "heartbeat" -> Unit
                }
            } catch (e: Exception) {
                Log.w(TAG, "bad message: $message")
            }
        }

        override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
            val id = connIds.remove(conn)
            if (id == appId) {
                bound = false
                appId = null
                log("DG-LAB App 断开连接")
            }
        }

        override fun onError(conn: WebSocket?, ex: Exception) {
            Log.w(TAG, "server error: ${ex.message}")
        }

        fun sendHeartbeats() {
            connIds.forEach { (conn, id) ->
                val peer = if (id == Config.clientId) (appId ?: id) else Config.clientId
                try {
                    sendTo(conn, id, peer, "400", type = "heartbeat")
                } catch (e: Exception) {
                    Log.w(TAG, "heartbeat: ${e.message}")
                }
            }
        }
    }

    private fun sendTo(conn: WebSocket, cid: String, tid: String, body: String, type: String) {
        val json = JSONObject().apply {
            put("type", type)
            put("clientId", cid)
            put("targetId", tid)
            put("message", body)
        }
        conn.send(json.toString())
    }

    // ------------------------------------------------------------------
    // 控制端客户端
    // ------------------------------------------------------------------

    private inner class CtrlClient(uri: URI) : WebSocketClient(uri) {
        override fun onOpen(handshake: ServerHandshake) {
            log("控制端已连接本地服务端")
        }

        override fun onMessage(message: String) {
            try {
                val o = JSONObject(message)
                when (o.optString("type")) {
                    "bind" -> if (o.optString("message") == "200") bound = true
                    "msg" -> {
                        val b = o.optString("message")
                        if (b.startsWith("strength-") && b.count { it == '+' } == 3) {
                            log("设备状态：$b")
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }

        override fun onClose(code: Int, reason: String?, remote: Boolean) {
            bound = false
            log("控制端连接关闭：$reason")
        }

        override fun onError(ex: Exception) {
            Log.w(TAG, "client error: ${ex.message}")
        }
    }
}
