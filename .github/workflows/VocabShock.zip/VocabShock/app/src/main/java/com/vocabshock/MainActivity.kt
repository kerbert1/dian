package com.vocabshock

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter

class MainActivity : Activity() {

    private lateinit var statusTv: TextView
    private lateinit var addrTv: TextView
    private lateinit var qrIv: ImageView
    private lateinit var logTv: TextView
    private var lastQr: String? = null
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Config.load(this)
        DgLabBridge.logSink = { msg -> ui.post { appendLog(msg) } }
        DgLabBridge.ensureStarted(this)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        statusTv = TextView(this).apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(Color.BLACK) }
        root.addView(statusTv)

        qrIv = ImageView(this).apply {
            setPadding(0, dp(8), 0, dp(8))
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(qrIv)

        addrTv = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.DKGRAY)
            setHorizontallyScrolling(true)
        }
        root.addView(addrTv)

        root.addView(checkbox("总开关（关闭后不再输出）", Config.enabled) { Config.enabled = it })
        root.addView(checkbox("调试模式（记录所有点击，用于确认按钮文字）", Config.debug) { Config.debug = it })
        root.addView(checkbox("实验性：下发自定义波形脉冲", Config.useWaveform) { Config.useWaveform = it })

        section(root, "监听目标")
        root.addView(field("目标 App 包名（留空=全部）", Config.targetPackage) { Config.targetPackage = it })
        root.addView(field("关键词·不认识档", Config.wordsHard) { Config.wordsHard = it })
        root.addView(field("关键词·忘记档", Config.wordsMid) { Config.wordsMid = it })
        root.addView(field("关键词·模糊档", Config.wordsLight) { Config.wordsLight = it })

        section(root, "三档强度与时长")
        root.addView(numberInt("「不认识」强度 (0-200)", Config.strengthHard) { Config.strengthHard = it })
        root.addView(numberLong("「不认识」时长 (毫秒)", Config.durationHard) { Config.durationHard = it })
        root.addView(numberInt("「忘记」强度 (0-200)", Config.strengthMid) { Config.strengthMid = it })
        root.addView(numberLong("「忘记」时长 (毫秒)", Config.durationMid) { Config.durationMid = it })
        root.addView(numberInt("「模糊」强度 (0-200)", Config.strengthLight) { Config.strengthLight = it })
        root.addView(numberLong("「模糊」时长 (毫秒)", Config.durationLight) { Config.durationLight = it })

        section(root, "安全限制")
        root.addView(numberInt("强度硬上限（强烈建议 ≤60）", Config.hardMaxStrength) { Config.hardMaxStrength = it })
        root.addView(numberLong("单次时长上限 (毫秒)", Config.maxDuration) { Config.maxDuration = it })
        root.addView(numberLong("冷却时间 (毫秒)", Config.cooldownMs) { Config.cooldownMs = it })
        root.addView(numberInt("每分钟最多触发次数", Config.maxPerMinute) { Config.maxPerMinute = it })

        section(root, "设备与网络")
        root.addView(numberInt("输出通道（1=A, 2=B）", Config.channel) { Config.channel = it.coerceIn(1, 2) })
        root.addView(numberInt("通道编号基准（1: A=1/B=2；0: A=0/B=1）", Config.channelBase) { Config.channelBase = it.coerceIn(0, 1) })
        root.addView(numberInt("服务端端口", Config.port) { Config.port = it })
        root.addView(field("局域网 IP 覆盖（连不上时手动填）", Config.ipOverride) { Config.ipOverride = it })

        section(root, "操作")
        root.addView(button("测试输出一次（轻档）") { DgLabBridge.testPulse() })
        root.addView(button("紧急停止（双通道归零+关总开关）") { DgLabBridge.emergencyStop(); Config.save(this); refreshStatus() })
        root.addView(button("重启本地服务") { DgLabBridge.restart(this) })
        root.addView(button("复制配对地址") { copy(DgLabBridge.qrContent(this)); toast("已复制") })
        root.addView(button("打开无障碍设置（必须手动开启）") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("申请忽略电池优化（防止服务被杀）") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            } catch (e: Exception) {
                toast("无法跳转，请手动在设置中关闭本 App 的电池优化")
            }
        })

        section(root, "日志")
        logTv = TextView(this).apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f); setTextColor(Color.DKGRAY) }
        root.addView(logTv)

        requestNotifyPermission()
        askBatteryIgnore()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        DgLabBridge.logSink = { msg -> ui.post { appendLog(msg) } }
        ui.post(ticker)
        refreshStatus()
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        Config.save(this)
        super.onPause()
    }

    override fun onDestroy() {
        DgLabBridge.logSink = null
        super.onDestroy()
    }

    // ---------------- UI 辅助 ----------------

    private fun refreshStatus() {
        val bound = DgLabBridge.bound
        val ip = Config.ipOverride.ifBlank { DgLabBridge.lanIp() }
        statusTv.text = buildString {
            append("服务：运行中 (端口 ${Config.port})\n")
            append("本机 IP：$ip\n")
            append("DG-LAB：").append(if (bound) "✅ 已绑定" else "❌ 未绑定（请用 DG-LAB 扫码）")
        }
        val content = DgLabBridge.qrContent(this)
        addrTv.text = content
        if (content != lastQr) {
            lastQr = content
            qrIv.setImageBitmap(qr(content, 600))
        }
        if (bound) Notifications.show(this)
    }

    private fun appendLog(msg: String) {
        val line = logTv.text.toString()
        val next = if (line.length > 3000) msg else "$msg\n$line"
        logTv.text = next
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#1A73E8"))
            setPadding(0, dp(14), 0, dp(4))
        })
    }

    private fun checkbox(title: String, checked: Boolean, onChanged: (Boolean) -> Unit): CheckBox {
        return CheckBox(this).apply {
            text = title
            isChecked = checked
            setTextColor(Color.BLACK)
            setOnCheckedChangeListener { _, v ->
                onChanged(v)
                Config.save(this@MainActivity)
            }
        }
    }

    private fun field(hint: String, value: String, onChanged: (String) -> Unit): EditText {
        return EditText(this).apply {
            setHint(hint)
            setText(value)
            setTextColor(Color.BLACK)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
            addTextChangedListener(simpleWatcher { onChanged(it); Config.save(this@MainActivity) })
        }
    }

    private fun numberInt(hint: String, value: Int, onChanged: (Int) -> Unit): EditText {
        return EditText(this).apply {
            setHint(hint)
            setText(value.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.BLACK)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
            addTextChangedListener(simpleWatcher { s ->
                val v = s.toIntOrNull() ?: return@simpleWatcher
                onChanged(v)
                Config.save(this@MainActivity)
            })
        }
    }

    private fun numberLong(hint: String, value: Long, onChanged: (Long) -> Unit): EditText {
        return EditText(this).apply {
            setHint(hint)
            setText(value.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.BLACK)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
            addTextChangedListener(simpleWatcher { s ->
                val v = s.toLongOrNull() ?: return@simpleWatcher
                onChanged(v)
                Config.save(this@MainActivity)
            })
        }
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
        }
    }

    private fun simpleWatcher(after: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after2: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) { after(s?.toString() ?: "") }
    }

    private fun qr(content: String, size: Int): Bitmap? {
        return try {
            val matrix = MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
            val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrix.width) {
                for (y in 0 until matrix.height) {
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            bmp
        } catch (e: Exception) {
            null
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("dglab", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun requestNotifyPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    private fun askBatteryIgnore() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
