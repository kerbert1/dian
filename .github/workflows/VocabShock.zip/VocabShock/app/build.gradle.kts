plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vocabshock"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vocabshock"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // WebSocket 服务端 / 客户端（DG-LAB SOCKET 协议需要自建服务端）
    implementation("org.java-websocket:Java-WebSocket:1.5.3")
    // 生成配对二维码
    implementation("com.google.zxing:core:3.5.3")
}
